<?php
$page_title= 'Contact Us';
include 'includes/header.php';
 ?>
    <body>




        <?php
        include 'includes/navigation.php';
         ?>
         <?php
          if (isset($_SESSION['userId'])) {
            echo '<div class="main-content">
   <div class="jumbotron contact-content">
      <h1 class="text-center textcontact">Contact Us</h1>
      <hr>
      <div class="text-center">
      <div class="btn-group btn-group-lg" role="group" aria-label="...">
      <a href="https://slack.com"><button type="button" class="btn btn-danger"><i class="fab fa-slack"></i></button></a>
      <a href="https://twitter.com"><button type="button" class="btn btn-danger"><i class="fab fa-twitter-square"></i></button></a>
      <a href="https://discord.com"><button type="button" class="btn btn-danger"><i class="fab fa-discord"></i></button></a>
      <a href="https://gmail.com"><button type="button" class="btn btn-danger"><i class="fas fab fa-at"></i></button></a>
      <a href="https://facebook.com"><button type="button" class="btn btn-danger"><i class="fab fa-facebook-square"></i></button></a>
      </div>

      </div>
   </div>
</div>
</div>
<!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Menu Toggle Script -->
<script>
   $("#menu-toggle").click(function(e) {
       e.preventDefault();
       $("#wrapper").toggleClass("toggled");
   });
</script>
<!-- Temp Login JS -->';

          }
          else {
            echo '<div class="container">
                <div class="row">
                  <div class="col-lg-12 text-center">
                    <h1 class="mt-5">Please <a href="login.php">Log in</a></h1>
                    <p class="lead">Or <a href="register.php">Sign Up</a> now to enjoy Bet Crypto</p>
                    <ul class="list-unstyled">
                      <li>BetCrypto &copy;</li>
                      <li>poop</li>
                    </ul>
                  </div>
                </div>
              </div>';
          }
          ?>


    </body>
</html>
