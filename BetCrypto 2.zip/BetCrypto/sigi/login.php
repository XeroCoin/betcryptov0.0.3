<?php
$page_title = "Sign Up";
include 'includes/header.php';
 ?>
<!DOCTYPE html>
<html>
<body>

<div id="header">
 Log In Page
</div>
<a href="register.php">Sign Up</a>


<?php if (isset($_GET["newpwd"])) {
  if ($_GET["newpwd"] == "passwordupdated") {
    echo "your password has been updated";
  }
} ?>

<form class="container container-fluid border border-light p-5"  id="myform" type="post" action="../sigi/includes/login.inc.php" method="post">

    <p class="h4 mb-4 text-center">Sign in</p>

    <input required="required" type="text"  value="" name="loginuname"  size="20" id="defaultLoginFormEmail" class="form-control mb-4" placeholder="Username or E-mail">

    <input required="required" type="password" value="" name="loginpassword" id="defaultLoginFormPassword" class="form-control mb-4" placeholder="Password">

    <div class="d-flex justify-content-between">
        <div>
            <div class="custom-control custom-checkbox">
                <input type="checkbox" class="custom-control-input" id="defaultLoginFormRemember">
                <label class="custom-control-label" for="defaultLoginFormRemember">Remember me</label>
            </div>
        </div>
        <div>
            <a href="reset.php">Forgot password?</a>
        </div>
    </div>

    <button class="btn btn-info btn-block my-4" id="btnlogin" name="btnlogin" value="Submit" type="submit">Sign in</button>

    <div class="text-center">
        <p>Not a member?
            <a href="">Register</a>
        </p>
    </div>
</form>



<?php


  if (!isset($_GET['login'])) {
    exit();

  }
  else {
    $signCheck = $_GET['login'];

    if ($signCheck == "emptyfields") {
      echo "<p class='error'>You did not fill in all of the required fields!</p>";
      exit();
    }

    elseif ($signCheck == "wrongpassword") {
      echo "<p class='error'>That is the incorrect password</p>";
      exit();
    }
    elseif ($signCheck == "errorsqllogin") {
      echo "<p class='error'>Cannot connect, please try again later.</p>";
      exit();
    }
    elseif ($signCheck == "nouser") {
      echo "<p class='error'>This user does not exist!</p>";
      exit();
    }
    }
 ?>
</body>


</html>
