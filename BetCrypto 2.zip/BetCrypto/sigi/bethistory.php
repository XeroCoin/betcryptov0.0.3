<?php
$page_title = 'Bet History';
include 'includes/header.php';

?>

    <body>
      <div id="wrapper">
          <?php
          include 'includes/navigation.php';
           ?>


           <?php
           if (isset($_SESSION['userId'])) {
             echo '<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
               <div class="container-fluid">
                 <a href="#menu-toggle" class="btn btn-secondary btn-menu wave-effect" id="menu-toggle"><i class="fas fa-bars"></i></a>
                 <a class="navbar-brand" href="#">LOGO</a>
                 <div class="login-logout">
                   <ul class="nav navbar-nav navbar-right">
                     <li></li>
                   </ul>
                 </div>
               </div>
             </nav>';

             require 'includes/db2.inc.php';
             $name = $_SESSION['uname'];
             $whichpage = $_GET['page'];



             if ($whichpage == "" || $whichpage == 1) {
               $thispage = 0;
             }
             else{
               $thispage=($whichpage * 10) - 10;
             }


             $sql = "SELECT * FROM usersRecordedBets WHERE betterName=? limit $thispage,10";
             $stmt = mysqli_stmt_init($conn);
             if (!mysqli_stmt_prepare($stmt, $sql)) {
               header("location: /Betcrypto/sigi/index.php?login=errorsqllogin");
               exit();
             }
             else {
               mysqli_stmt_bind_param($stmt, "s", $name);
               mysqli_stmt_execute($stmt);
               $res = mysqli_stmt_get_result($stmt);
               $my_arary = array();
               while($row = mysqli_fetch_assoc($res)){
               $my_arary[] = $row;



             }

             }
             $sql = "SELECT * FROM usersRecordedBets WHERE betterName=?";
             $stmt = mysqli_stmt_init($conn);
             if (!mysqli_stmt_prepare($stmt, $sql)) {
               header("location: /Betcrypto/sigi/index.php?login=errorsqllogin");
               exit();
             }
             else {
               mysqli_stmt_bind_param($stmt, "s", $name);
               mysqli_stmt_execute($stmt);
               $res = mysqli_stmt_get_result($stmt);
               $numberofrows = mysqli_num_rows($res);
             }
             echo '<div class="main-content">


                        <div class="jumbotron container bethistory-content">
                        <div class="panel panel-default">
                            <!-- Default panel contents -->

                            </div>

                          <table class="table">
                               <thead>
                                 <h5>Here are your past bets, '.$name.'</h5>
                                 <tr>
                                   <th scope="col">#</th>
                                   <th scope="col">Name of Bet</th>
                                   <th scope="col">Picked</th>
                                   <th scope="col">Amount</th>
                                 </tr>
                               </thead>
                               <tbody>';

                                   $i = 1;

                                   foreach ($my_arary as $lineitem) {
                                     echo  '<tr>';
                                     echo  '<td>'.($i++).'</td><td>'.$lineitem["nameOfBet"].'</td><td>'.$lineitem["picked"].'</td><td>'.$lineitem["betAmount"].'</td>';
                                     echo  '</tr>';
                                   }




                               echo '</tbody>
                               </table>

                               <div class="text-center">';
                               $pages = $numberofrows / 10;
                               $pages = ceil($pages);

                               for ($i=1; $i<=$pages; $i++) {
                                 ?><a href="bethistory.php?page=<?php echo $i;  ?>&pagenation="><?php echo $i; ?></a><?php
                               }

                               '</div>
                        </div>
             </div>
             </div>
             </div>';


           }
           else {
             echo '<div class="container">
                 <div class="row">
                   <div class="col-lg-12 text-center">
                     <h1 class="mt-5">Please <a href="login.php">Log in</a></h1>
                     <p class="lead">Or <a href="register.php">Sign Up</a> now to enjoy Bet Crypto</p>
                     <ul class="list-unstyled">
                       <li>BetCrypto &copy;</li>
                       <li>poop</li>
                     </ul>
                   </div>
                 </div>
               </div>';
           }

            ?>


    <!-- Temp Login JS -->
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.6.1/js/mdb.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

    </body>
</html>
