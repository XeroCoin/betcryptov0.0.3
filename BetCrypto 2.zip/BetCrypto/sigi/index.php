
<!DOCTYPE html>
<?php session_start(); ?>
<html lang="en" dir="ltr">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="shortcut icon" href="https://img.icons8.com/color/48/000000/get-cash.png" type="image/x-icon" />
    <title>BETCOINCASH</title>

    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.6.1/css/mdb.min.css" rel="stylesheet">

    <link href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Alfa+Slab+One" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Alfa+Slab+One|BioRhyme|Black+Ops+One|Bungee|Bungee+Shade|Creepster|Ewert|Fruktur|Gravitas+One|Monoton|Rubik:900" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="../sigi/css/simple-sidebar.css" rel="stylesheet">
    <link href="../sigi/css/dex.css" rel="stylesheet">
  </head>



<body>

    <div id="wrapper">
        <!-- Sidebar -->
        <div class="sidebar sidenav-bg" id="sidebar-wrapper">
            <ul class="sidebar-nav side-nav side-nav-light">
                <li class="sidebar-brand">
                    <a href="#">BETCOINCASH </a>
                </li>
                <li>
                    <a href="line.php">Lines</a>
                </li>
                <li>
                    <a href="bethistory.php">Bet History</a>
                </li>
                <li>
                    <a href="contact.php">Contact Us</a>
                </li>
            </ul>
</div>
        <!-- /#sidebar-wrapper -->



        <!-- Page Content -->

        <div id="firstsection-wrapper">
          <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
            <div class="container-fluid">
              <a href="#menu-toggle" class="btn btn-secondary btn-menu wave-effect" id="menu-toggle"><i class="fas fa-bars"></i></a>
              <a class="navbar-brand" href="#">LOGO</a>
              <div class="login-logout">
                <ul class="nav navbar-nav navbar-right">
                  <li><?php
                  if (isset($_SESSION['uname'])) {
                    echo '<form action="/Betcrypto/sigi/includes/logout.inc.php" method="post">
                    <button class="btn btn-danger btn-logout" type="submit" name="logout">Logout</button>
                  </form>';
                  }
                  else {
                    echo '<a href="login.php">Login</a>';
                  }?></li>
                </ul>
              </div>
            </div>
          </nav>
</div>
<div id="page-content">


  <div class="jumbotron jumbotron-fluid headline">
        <h1 class=" text-center">Welcome to BETCOINCASH</h1>
        <div class="container">
          <p class="text-justify text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
        </div>
      </div>
      <div class="weaccept">
        <h3 class="text-center headline-text">We accept the following</h3>
        <ul class="accept-list text-center">
          <li><a href="#"><img src="https://i.imgur.com/3iS0Y7Q.png" alt=""></a></li>
          <li><a href="#"><img src="https://pennykoin.com/images/pk-logo-v3-134.png" alt=""></a></li>
          <li><a href="#"><img src="https://www.getmonero.org/press-kit/symbols/monero-symbol-480.png" alt=""></a></li>
          <li><a href="#"><img src="https://assets.coingecko.com/coins/images/3736/large/2629.png?1523325602" alt=""></a></li>
        </ul>
      </div>
      <div id="howitworks" class="placetext container text-center">
        <div class="jumbotron ">
          <h1>HOW DOES BETCOINCASH WORK?</h1>
          <p>In order to place a wager on BETCOINCASH, simply log in to your BETCOINCASH account, and select a side of a proposal (Over or Under).</p>
          <p>Follow the corresponding instructions to ensure your wager is received properly. On BETCOINCASH, we will never ask you to deposit any currency directly to our website. Instead, simply send the currency you choose to the provided address, and your wager will be logged automatically.</p>
          <p>In addition, no user action is required in order to receive payouts for winning wagers. Payments are made automatically to the receiving addresses provided by those who chose the winning side of the proposal.</p>
          <p>The amount paid will vary based on the amount of money wagered on either side of the proposition.</p>
          <br>
          <br>
          <h5><span class="greenish">For instance:</span></h5>
          <p>Proposal A has two options to wager on: Over or Under. A total of $100 is wagered on the Over, and $100 is wagered on the Under. Therefore, the total pot for Proposal A is $200.</p>
          <p>Player A has wagered $10 on the Over, which is 10% of the total money wagered on the Over. If the Over wins, Player A is entitled to a percentage of the total pot for Proposal A equivalent to the percentage of his wager compared to the total money wagered on the Over, in this case 10%. Therefore, Player A would receive a payout of $20.</p>
          <h5><span class="greenish">Another example:</span></h5>
          <p>Proposal B has two options to wager on: Over or Under. A total of $10 is wagered on the Over, and $100 is wagered on the Under. Therefore, the total pot for Proposal A is $110.</p>
          <p>Player A has wagered $5 on the Over, which is 50% of the total money wagered on the Over. If the Over wins, Player A is entitled to a percentage of the total pot for Proposal A equivalent to the percentage of his wager compared to the total money wagered on the Over, in this case 50%. Therefore, Player A would receive a payout of $55.</p>
          <h5><span class="greenish">One more example:</span></h5>
          <p>Proposal C has two options to wager on: Over or Under. A total of $100 is wagered on the Over, and $10 is wagered on the Under. Therefore, the total pot for Proposal A is $110.</p>
          <p>Player A has wagered $10 on the Over, which is 10% of the total money wagered on the Over. If the Over wins, Player A is entitled to a percentage of the total pot for Proposal A equivalent to the percentage of his wager compared to the total money wagered on the Over, in this case 10%. Therefore, Player A would receive a payout of $11.</p>
          <br><br>

          <li>(X/Y)(Z)=Payout</li>
          <li>X=Amount wagered on Winning Proposal Option</li>
          <li>Y=Total amount wagered on Winning Proposal Option</li>
          <li>Z=Total amount wagered on Both Proposal Options</li>
        </div>
      </div>
      <footer class="page-footer font-small teal pt-4">

    <!-- Footer Text -->
    <div class="container-fluid text-center text-md-left">

      <!-- Grid row -->
      <div class="row">

        <!-- Grid column -->
        <div class="col-md-12 mt-md-0 mt-3">

          <!-- Content -->
          <h5 class="text-uppercase text-center font-weight-bold">Follow us at</h5>
          <div class="text-center">
            <a href="https://slack.com"><button type="button" class="btn btn-danger"><i class="fab fa-slack"></i></button></a>
            <a href="https://twitter.com"><button type="button" class="btn btn-danger"><i class="fab fa-twitter-square"></i></button></a>
            <a href="https://discord.com"><button type="button" class="btn btn-danger"><i class="fab fa-discord"></i></button></a>
            <a href="https://gmail.com"><button type="button" class="btn btn-danger"><i class="fas fab fa-at"></i></button></a>
            <a href="https://facebook.com"><button type="button" class="btn btn-danger"><i class="fab fa-facebook-square"></i></button></a>
          </div>

        </div>
        <!-- Grid column -->


        <!-- Grid column -->

      </div>
      <!-- Grid row -->

    </div>
    <!-- Footer Text -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-3">© 2018 Copyright:
      <a href="">BETCOINCASH.io</a>
    </div>
    <!-- Copyright -->

  </footer>
  <!-- Footer -->
</div>
</div>


    <!-- /#wrapper -->

    <!-- Bootstrap core JavaScript -->
    <!-- JQuery -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.6.1/js/mdb.min.js"></script>

    <!-- Menu Toggle Script -->
    <script>
    $("#menu-toggle").click(function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
    });
    </script>

  </body>
</html>
