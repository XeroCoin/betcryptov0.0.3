<?php
  $page_title = 'Bet Form';
  include 'includes/header.php';
 ?>

<body>

  <?php
  include 'includes/navigation.php';

   ?>

        <!-- /#sidebar-wrapper -->



        <!-- Page Content -->
<?php
  if(isset($_SESSION['userId'])){
    echo '
    <div class="main-content">
    <div class="jumbotron betform-content" id="form">
    <h1 class="betform_header text-center">Confirm Bet</h1>
    <hr>
    <div class="styleform">
        <form class="align_form">
        <div class="form-group container">
          <ul id="betForm">

          </ul>
          <ul class="betform_amount">Bet Amount:</ul>
          <ul><input id="betAmount" type="number" ></ul>

        <button class="btn btn-primary btncnfrm" id="confirm" type="button">
        Confirm Bet
        </button>
        <br> <br>
        <input type="radio" id="pk" name="cointype1" value="PennyKoin">
        <label for="pk">PennyKoin</label>
        <input type="radio" id="trtl" name="cointype2" value="turtlecoin">
        <label for="trtl">TurtleCoin</label>


        </div>
        </form>
        <form class="align_form1" id="recordform" name="recform" type="post" method="post" action="../sigi/recordBet.php">
        </form>

        </div>
    </div>
</div>
     <!-- Bootstrap core JavaScript -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Menu Toggle Script -->
<script>
$("#menu-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
});
</script>

<!-- Temp Login JS -->

<script src="scripts/submitBet.js"></script>';

  }
else{
  echo '<div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h1 class="mt-5">Please <a href="login.php">Log in</a></h1>
          <p class="lead">Or <a href="register.php">Sign Up</a> now to enjoy Bet Crypto</p>
          <ul class="list-unstyled">
            <li>BetCrypto &copy;</li>
            <li>poop</li>
          </ul>
        </div>
      </div>
    </div>';
}
 ?>



</body>

</html>
