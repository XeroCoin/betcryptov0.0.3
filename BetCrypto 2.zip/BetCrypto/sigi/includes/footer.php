<footer class="page-footer font-small teal pt-4">

<!-- Footer Text -->
<div class="container-fluid text-center text-md-left">

<!-- Grid row -->
<div class="row">

  <!-- Grid column -->
  <div class="col-md-12 mt-md-0 mt-3">

    <!-- Content -->
    <h5 class="text-uppercase text-center font-weight-bold">Have Fun</h5>


  </div>
  <!-- Grid column -->


  <!-- Grid column -->

</div>
<!-- Grid row -->

</div>
<!-- Footer Text -->

<!-- Copyright -->
<div class="footer-copyright text-center py-3">© 2018 Copyright:
<a href="">BETCOINCASH.io</a>
</div>
<!-- Copyright -->

</footer>
