<?php


if (isset($_POST["resetreqsub"])) {
  $select = bin2hex(random_bytes(8));
  $tkn = random_bytes(32);

  $url = "http://localhost/Betcrypto/sigi/create-new-pass.php?selector=".$select."&validator=".bin2hex($tkn);
  $expires = date("U") +  900;

  require "dbh.inc.php";
  require "../includes/PHPMailer/PHPMailerAutoload.php";



  $userMail = $_POST['email'];
  $sql = "DELETE FROM resetpass WHERE resetEmail=?";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)) {
    echo "There was an error";
    exit();
  }
  else {
    mysqli_stmt_bind_param($stmt, "s", $userMail);
    mysqli_stmt_execute($stmt);
  }
  $sql = "INSERT INTO resetpass (resetEmail, resetSelect, resetToken, resetExp) VALUES (?, ?, ?, ?);";
  $stmt = mysqli_stmt_init($conn);
  if (!mysqli_stmt_prepare($stmt, $sql)) {
    echo "There was an error";
    exit();
  }
  else {
    $hashed = password_hash($tkn, PASSWORD_DEFAULT);
    mysqli_stmt_bind_param($stmt, "ssss", $userMail, $select, $hashed, $expires);
    mysqli_stmt_execute($stmt);
  }

  mysqli_stmt_close($stmt);
  mysqli_close($conn);

  $mail = new PHPMailer;
  $mail->isSMTP();
  $mail->SMTPAuth = true;
  $mail->SMTPSecure = 'ssl';
  $mail->Host = 'smtp.gmail.com';
  $mail->Port = 465;
  $mail->isHTML();
  $mail->Username = "cryptobet95@gmail.com";
  $mail->Password = "crypto123";
  $mail->SetFrom('noreply@betcrypto.com');
  $to = $userMail;
  $message = '<p>We received a password reset request. The link below is to reset your password. If you did not make this request please ignore this email.</p>';
  $message .= '<p>Here is your password reset link:</p>';
  $message .= '<a href="'.$url.'">'.$url.'</a>';
  $mail->Subject = 'Reset password for betcrypto';
  $mail->Body = $message;
  $mail->AddAddress($to);


  $mail->Send();


  header("Location: ../reset.php?reset=success");

}
else {
  header("Location ../index.php");
}
