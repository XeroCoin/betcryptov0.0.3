<?php
session_start();
if (isset($_SESSION['userId'])) {
  if (isset($_POST['subSend'])) {
    require 'db2.inc.php';
    require "../includes/PHPMailer/PHPMailerAutoload.php";
    $name = $_SESSION['uname'];
    $email = $_SESSION['umail'];
    $bname = $_POST['getbet'];
    $ovun = $_POST['getoverunder'];
    $betAmount = $_POST['getamount'];
    $paymentid = $_POST['getpayid'];
    $recaddy = $_POST['walletaddy'];
    $depositaddy = $_POST['betdepaddy'];
    $url = "http://localhost/Betcrypto/sigi/bethistory.php?page=&pagenation=";

    $sql = "INSERT INTO usersrecordedbets (betterName, nameOfBet, picked, betAmount, paymentID, userRecAddress) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_stmt_init($conn);
    if(!mysqli_stmt_prepare($stmt, $sql)){

      header('location: /Betcrypto/sigi/register.php?return=sqlreturn');
      exit();
    }
    else {
      mysqli_stmt_bind_param($stmt, "ssssss", $name, $bname, $ovun,$betAmount,$paymentid,$recaddy);
      mysqli_stmt_execute($stmt);

      header('location: /Betcrypto/sigi/index.php?bet=Success!');
    }
    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->SMTPAuth = true;
    $mail->SMTPSecure = 'ssl';
    $mail->Host = 'smtp.gmail.com';
    $mail->Port = 465;
    $mail->isHTML();
    $mail->Username = "cryptobet95@gmail.com";
    $mail->Password = "crypto123";
    $mail->SetFrom('noreply@betcrypto.com');
    $to = $email;
    $message = '<p>You have placed a wager with Betcrypto. See confirmation below.</p>';
    $message .= '<p>You have chosen the'.$ovun.'for the  following wager: '.$bname.' you have wagered the following amount:'.$betAmount.'Make sure you send your payment to '.$depositaddy.' using the following payment ID'.$paymentid.'</p>';
    $message .= '<p>you can expect payment one hour after line has ended</p>';

    $message .= '<a href="'.$url.'">See your bet history</a>';
    $mail->Subject = 'Confirmation of bet placed';
    $mail->Body = $message;
    $mail->AddAddress($to);


    $mail->Send();

  }
  else{
    header('location: /Betcrypto/sigi/recordBet.php?error=getouttahere');
  }
}
else{
  echo "Please Login";
}
