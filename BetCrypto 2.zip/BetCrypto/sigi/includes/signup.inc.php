<?php
	if(isset($_POST['btn'])){

		require 'dbh.inc.php';
		require "../includes/PHPMailer/PHPMailerAutoload.php";

		$userName = $_POST['uname'];
		$email = $_POST['email'];
		$pwd = $_POST['password'];
		$repeatPwd = $_POST['repeatpassword'];

		if(empty($userName) || empty($email) || empty($pwd) || empty($repeatPwd)){
			header('location: /Betcrypto/sigi/register.php?return=emptyfields&name='.$userName."&email=".$email);
			exit();
		}
		elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $userName)) {
			header('location: /Betcrypto/sigi/register.php?return=invalidmailandID');
			exit();

		}
		elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			header('location: /Betcrypto/sigi/register.php?return=invalidemail&name='.$userName);
			exit();
		}
		elseif (!preg_match("/^[a-zA-Z0-9]*$/", $userName)) {
			header('location: /Betcrypto/sigi/register.php?return=userinvalid&mail='.$email);
			exit();
		}
		elseif ($pwd !== $repeatPwd) {
			header('location: /Betcrypto/sigi/register.php?return=checkpassword&name='.$userName."&email=".$email);
			exit();
		}
		else {

			$sql = "SELECT gamblerName FROM gamblers WHERE gamblerName=? ";
			$stmt = mysqli_stmt_init($conn);



				if(!mysqli_stmt_prepare($stmt, $sql)){

					header('location: /Betcrypto/sigi/register.php?return=sqlreturn');
					exit();
				}
				else {
					mysqli_stmt_bind_param($stmt,  "s", $userName);
					mysqli_stmt_execute($stmt);
					mysqli_stmt_store_result($stmt);

					$resultchk = mysqli_stmt_num_rows($stmt);

					if($resultchk > 0){
						header('location: /Betcrypto/sigi/register.php?return=userTaken');
						exit();
					}
          else{
          $res = "SELECT * FROM gamblers WHERE gamblerEmail=?";
          $stmt = mysqli_stmt_init($conn);
          if(!mysqli_stmt_prepare($stmt, $res)){
    					header('location: /Betcrypto/sigi/register.php?return=sqlreturn');
  					exit();
  				}
          else{
          mysqli_stmt_bind_param($stmt,  "s", $email);
					mysqli_stmt_execute($stmt);
					mysqli_stmt_store_result($stmt);
          $numrow = mysqli_stmt_num_rows($stmt);
          if ($numrow > 0) {
            header('location: /Betcrypto/sigi/register.php?return=emailTaken');
						exit();
          }
           else{
						$sql = "INSERT INTO gamblers (gamblerName, gamblerEmail, GamblerPwd) VALUES (?, ?, ?)";
						$stmt = mysqli_stmt_init($conn);
						if(!mysqli_stmt_prepare($stmt, $sql)){

							header('location: /Betcrypto/sigi/register.php?return=sqlreturn');
							exit();
						}
						else {
							$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
							mysqli_stmt_bind_param($stmt, "sss", $userName, $email, $hashedPwd);
							mysqli_stmt_execute($stmt);
							$mail = new PHPMailer;
							$mail->isSMTP();
							$mail->SMTPAuth = true;
							$mail->SMTPSecure = 'ssl';
							$mail->Host = 'smtp.gmail.com';
							$mail->Port = 465;
							$mail->isHTML();
							$mail->Username = "cryptobet95@gmail.com";
							$mail->Password = "crypto123";
							$mail->SetFrom('noreply@betcrypto.com');
							$to = $email;
							$message = '<p>Stay tuned for  weekly events, wagers, and prizes.</p>';
							$mail->Subject = 'Thankyou for registering with Betcrypto';
							$mail->Body = $message;
							$mail->AddAddress($to);


							$mail->Send();
							header('location: /Betcrypto/sigi/register.php?return=Success!');
							exit();
						}
					}

				}

			}
      mysqli_stmt_close($stmt);
      mysqli_close($conn);



    }
	}

}
