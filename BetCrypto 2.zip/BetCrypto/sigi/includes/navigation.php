<?php if(isset($_SESSION['userId'])){
  $activeUser = $_SESSION['uname'];
  echo '

      <!-- Sidebar -->
      <div class="sidebar sidenav-bg" id="sidebar-wrapper">
          <ul class="sidebar-nav side-nav side-nav-light">
              <li class="sidebar-brand">
                  <a href="#">BETCOINCASH </a>
              </li>
              <li>
                  <a href="index.php">Home</a>
              </li>
              <li>
                  <a href="line.php">Lines</a>
              </li>
              <li>
                  <a href="bethistory.php">Bet History</a>
              </li>
              <li>
                  <a href="contact.php">Contact Us</a>
              </li>
          </ul>
</div>
';
}
else{
  echo ' <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <a class="navbar-brand" href="#">Bet Crypto</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse navbar-right" id="navbarTogglerDemo02">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="register.php">Sign up</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled" href="#">Contact</a>
      </li>
    </ul>

  </div>
</nav>';

}
?>
