var betTitleTarget = document.getElementById('betname');
var betAmount = document.getElementById('betAmount');
var betForm = document.getElementById('submitbetform');
function record(e){
  var clicked = e.innerHTML;
  var title = e.parentNode.parentNode.previousElementSibling.innerHTML;
  var text = "The " + clicked + " for " + title;
  betTitleTarget.innerHTML = text;
  localStorage.setItem('whichClicked', clicked);
  localStorage.setItem('wgrTitle', title);
}


$('#confirm').click(function(){
  if(betAmount.value.length == 0){
    alert("Please enter a bet amount.");
  }
  else if (betAmount.value <= 0) {
    alert("Please enter a bet greater than 0");
}
else {
  var newButton = document.createElement("button");
  newButton.setAttribute("type", "submit");
  newButton.setAttribute("class", "btn btn-primary btnsub");
  newButton.innerHTML = "Submit";
  betForm.appendChild(newButton);
  localStorage.setItem('howmuch', betAmount.value);
}
});
