var bet = localStorage.getItem('wgrTitle');
var oU = localStorage.getItem('whichClicked');
var myAmount = localStorage.getItem('howmuch');
var setBetName = document.getElementById('setBet');
var setOU = document.getElementById('o_u');
var setAmt = document.getElementById('setAmt');
var depAddy = document.getElementById('depAddy');
var pmtID = document.getElementById('pmtID');
var depositAddress = "TRTLuy9jrD2iYYMH7bWgxt7ZZRToVb4x5QP2G3tPaZLFVwt6BebGFcYAQisBLFTpZUFe4H5eVUSNmbgwygDMwtAta95BBxyVJiV";
var betphp = document.getElementById('namebet');
var oUphp = document.getElementById('overunder');
var amountphp = document.getElementById('amountbet');
var pmtidphp = document.getElementById('betpayid');
var depaddyphp = document.getElementById('betrecaddy');
var payoutaddy = document.getElementById('payoutAddress');
var depositaddr = document.getElementById('ourdepaddy');
console.log(oU);
function makepaymentid(){
  var result = "";
  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  for (var i = 0; i < 30; i++) {
    result += possible.charAt(Math.floor(Math.random()*possible.length));
  }
  return result;
}

var payid = makepaymentid();

setBetName.innerHTML = bet;
setOU.innerHTML = oU;
setAmt.innerHTML = myAmount;
depAddy.innerHTML = depositAddress;
pmtID.innerHTML = payid;

$('#openmodal').click(function(){
  if (payoutaddy.value.length == 0) {
    alert("Please enter a valid payout address");
    $("#confirm").prop('disabled', true);
  }else {
    $("#confirm").prop('disabled', false);
    betphp.value = bet;
    oUphp.value = oU;
    amountphp.value = myAmount;
    pmtidphp.value = payid;
    depositaddr.value = depositAddress;
  }

});
