<?php
$page_title = "Reset  Password";
require "includes/header.php"
?>

<main>
  <div class="wrapper-main">
    <section class="section-default">
      <?php
        $selector = $_GET["selector"];
        $valid = $_GET["validator"];

        if (empty($selector) || empty($valid)) {
          echo "could not validate request";

        }
        else {
          if (ctype_xdigit($selector) !== false && ctype_xdigit($valid)){
            ?>
          <nav class="navbar navbar-expand-lg navbar-light bg-light navbar-fixed-bottom">
            <a class="navbar-brand" href="#">Bet Crypto</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse navbar-right" id="navbarTogglerDemo02">
              <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <li class="nav-item active">
                  <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="register.php">Sign up</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link disabled" href="#">Contact</a>
                </li>
              </ul>

            </div>
          </nav>
<br><br><br>
            <form class="text-center"action="includes/replacepass.inc.php" method="post">
              <input type="hidden" name="selector" value="<?php echo $selector;?>">
              <input type="hidden" name="validator" value="<?php echo $valid;?>">
              <input type="password" name="pwd" placeholder="Enter a new password...">
              <input type="password" name="pwd-rpt" placeholder="Repeat your new password...">
              <button type="submit" name="resetpwdsub">Reset Password</button>
            </form>
            <?php
          }
        }
       ?>

       <ul class="list-unstyled text-center">
         <li>BetCrypto &copy;</li>
         <li>poop</li>
       </ul>
    </section>

  </div>
</main>
