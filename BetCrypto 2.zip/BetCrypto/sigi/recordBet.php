
<?php

$page_title = 'Record Bet';
include 'includes/header.php';
$activeUser = $_SESSION['uname'];
 ?>
 <body>

   <?php
   if (isset($_SESSION['userId'])) {

     echo '<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
       <div class="container-fluid">
         <a class="navbar-brand" href="#">LOGO</a>
         <div class="login-logout">
           <ul class="nav navbar-nav navbar-right">
             <li><a href="#">Login</a> </li>
           </ul>
         </div>
       </div>
     </nav>
     <form class="recordbet-content container" id="sndBet" action="../sigi/includes/sendbet.inc.php" method="post">
       <div class="form-group jumbotron">
          <div class="" id="allinfo">
            <h2 class="recordbet-header">Please review the following information below</h2>
            <br>
            <br>


            <h6 class="user" name="user" >User: '.$activeUser.'</h6>

            <br>
            <br>
            <span class="badge badge-warning bdge">Step One</span>
            <br>
            <br>
            <div class="container pg-container">
            <div class="pding">
            <h6>Bet Name:</h6>
            <p class="confirm-content" id="setBet" name="bet"> </p>


            <h6>You have chosen the: </h6>
            <p class="confirm-content" id="o_u" name="ovun"></p>

            <h6>Bet Amount: </h6>
            <p class="confirm-content" id="setAmt" name="amt"></p>
            </div>
            </div>
            <br>
            <br>
            <span class="badge badge-warning bdge">Step Two</span>
            <br>
            <br>
            <div class="container pg-container">
            <div class="pding">
            <h6>Please deposit funds to the following address: </h6>
            <p class="confirm-content" id="depAddy" name="deposit"></p>

            <h6>Please send funds with the following Payment ID: </h6>
            <p class="confirm-content" id="pmtID" name="idPMT"></p>
            </div>
            </div>
            <br><br><br>
            <span class="badge badge-warning bdge">Step Three</span>
            <br>
            <br>
            <div class="container pg-container">
            <div class="pding">
            <h6>Please enter the address you would your payout sent to:</h6>
            <input type="text" id="payoutAddress" size="55" name="walletaddy" placeholder="Please enter the address you would your payout sent to">
            </div>
            </div>
            <br><br><br>


            <input type="hidden" id="namebet" name="getbet" >
            <input type="hidden" id="overunder" name="getoverunder" value="">
            <input type="hidden" id="amountbet" name="getamount" value="">
            <input type="hidden" id="betpayid" name="getpayid" value="">
            <input type="hidden" id="ourdepaddy" name="betdepaddy" value="">
            <button type="button" id="openmodal" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">
            Submit
            </button>
          </div>
       </div>
       </div>
       <!-- Modal -->
       <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
         <div class="modal-dialog modal-notify modal-success modal-dialog-centered" role="document">
           <div class="modal-content">
             <div class="modal-header">
               <h5 class="modal-title" id="exampleModalLongTitle">Are you sure you would like to place this bet?</h5>
               <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                 <span aria-hidden="true">&times;</span>
               </button>
             </div>
             <div class="modal-body">
               <h6>Disclosures:</h6>
               <br>
               <p class="disclosures">Please note that By signing up for an account, you assume all responsibility for complying with your own local, national, federal, state, or other laws concerning betting and gaming prior to opening an account or using any services provided by BETCOINCASH.
When placing a wager, the user (you) assumes all responsibility for sending the correct currency to the correct address with the corresponding payment id, in addition to providing an active personal address for the correct currency in order to register their wager and receive potential payouts. Failure to do so may result in loss of user funds.</p>
             </div>
             <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
               <button type="submit" id="confirm" name="subSend" class="btn btn-success">Confirm</button>
             </div>
           </div>
         </div>
       </div>
     </form>';




   }
   else{
     echo '<div class="container">
         <div class="row">
           <div class="col-lg-12 text-center">
             <h1 class="mt-5">Please <a href="login.php">Log in</a></h1>
             <p class="lead">Or <a href="register.php">Sign Up</a> now to enjoy Bet Crypto</p>
             <ul class="list-unstyled">
               <li>BetCrypto &copy;</li>
               <li>poop</li>
             </ul>
           </div>
         </div>
       </div>';
   }
    ?>


   <script src="vendor/jquery/jquery.min.js"></script>
   <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
   <script src="scripts/sendtodb.js"></script>

   <!-- Menu Toggle Script -->



   </body>
 </html>
