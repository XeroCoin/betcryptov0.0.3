<?php
  $page_title = "Tonight's Slate";
  include 'includes/header.php';

 ?>

 <body>
   <div id="wrapper">
   <?php include 'includes/navigation.php' ?>
   <?php
     if(isset($_SESSION['userId'])){
       echo '
   <div class="navbarwrap" id="navbarwr">
         <nav class="navbar navbar-default navbar-fixed-top" role="navigation">
           <div class="container-fluid">
             <a href="#menu-toggle" class="btn btn-secondary btn-menu wave-effect" id="menu-toggle"><i class="fas fa-bars"></i></a>
             <a class="navbar-brand" href="index.php">LOGO</a>
             <p class="title_name">Welcome, ';?><?php echo $activeUser;?> <?php echo '</p>
             <div class="login-logout">
               <a href="https://twitter.com"><i class="fab fa-twitter-square icon-large"></i></a>
               <a href="https://discord.com"><i class="fab fa-discord icon-large"></i></a>
             </div>
               <ul class="nav navbar-nav navbar-right">
                 <form action="/Betcrypto/sigi/includes/logout.inc.php" method="post">
                 <button class="btn btn-danger btn-logout" type="submit" name="logout">Logout</button>
               </form>
               </ul>
         </nav>
       </div>

<div id="page-content">
<div class="pagewrap container" id="pgwrap">
  <div class="card c1">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 1</p>
<div class="buttons">
    <div id="undercontainer1" class="under">
      <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
      <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>
  </div>
</div>
<div class="card c2">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 2</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>
  </div>
</div>
<div class="card c3">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 3</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>



  </div>
</div>
<div class="card c4">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 4</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>



  </div>
</div>
<div class="card c5">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 5</p>
    <div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>
  </div>
</div>
<div class="card c6">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 6</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>



  </div>
</div>
<div class="card c7">
  <div class="card-body">

    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 7</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>


  </div>
</div>
<div class="card c8">
  <div class="card-body">
    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 8</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="over1" onclick="record(this)" class="btn btn-primary btn-lg btnover" data-toggle="modal" data-target="#exampleModalCenter">Under</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>



  </div>
</div>
<div class="card c9">
  <div class="card-body">

    <h6 class="card-title">The data for this wager has been sourced from</h6>
    <p>example bet 9</p>
<div class="buttons">
    <div class="under">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
    <div class="over">
        <button type="button" id="under1"  onclick="record(this)" class="btn btn-primary btn-lg btnunder" data-toggle="modal" data-target="#exampleModalCenter">Over</button>
    </div>
  </div>


  </div>
</div>
</div>
</div>
<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-notify modal-warning modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">You have chosen the following Wager</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form class="align_form" id="submitbetform" name="recform" type="post" method="post" action="../sigi/recordBet.php">
        <div class="form-group container">
          <ul id="betname">
          </ul>
          <ul class="betform_amount">Bet Amount:</ul>
          <ul><input id="betAmount" type="number" ></ul>
        </div>

        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="confirm" class="btn btn-primary">Confirm</button>
      </div>
    </div>
  </div>
</div>
 </div>
 </div>';
 include 'includes/footer.php';
}
 else {
   echo '<div class="container">
       <div class="row">
         <div class="col-lg-12 text-center">
           <h1 class="mt-5">Please <a href="login.php">Log in</a></h1>
           <p class="lead">Or <a href="register.php">Sign Up</a> now to enjoy Bet Crypto</p>
           <ul class="list-unstyled">
             <li>BetCrypto &copy;</li>
             <li>poop</li>
           </ul>
         </div>
       </div>
     </div>';
   }

?>


 <!-- Bootstrap core JavaScript -->
 <!-- JQuery -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.6.1/js/mdb.min.js"></script>




        <!-- Menu Toggle Script -->
        <script>
        $("#menu-toggle").click(function(e) {
          e.preventDefault();
          $("#wrapper").toggleClass("toggled");
        });
        </script>
        <!-- Temp Login JS -->

        <script src="scripts/submitBet.js"></script>
 </body>
 </html>
